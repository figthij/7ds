/*
project name: Class7ds
program:Class7ds
Author: Erik Bailey
Date: Oct 29 2020
Synoposis: 
Makes random numbers finds the largest one and tells what index of the array 
it is at and does so with all other number
*/
package pkgclass.pkg7.ds;
public class Class7Ds {
    public static void main(String[] args) {
        raninputnum ran=new raninputnum();
        largest lar = new largest();
        search sea=new search();
        int size=1000000;
        int half=10000;
        int[] value = new int[size];
        int i =0;
        int large;
        while(i<size){
            ran.raninputnum(value, i);
            i=i+1;
        }
        large=lar.largestinlist(value, size);//large is the highest value in the list
        int large1=large +1;//large1 means large+1
        int[][] a;
        a = new int[large1][half];
        int num=large;
        while(num!=-1){
            int[] a1=new int[half];
            a1=sea.recSearch(value,0,size-1,num,a1,0);
            System.arraycopy(a1, 0, a[num], 0, a1.length); //if(a1[j]!=-1){
            num=num-1;
        }
        System.out.println();
        for(int q = 0; q<1000;q++){//pointer replacement
            System.out.println(q+" is at the values: ");
            for(int w = 0; w<half;w++){
                if(a[q][w]!=-1){
                    System.out.print(a[q][w]+" ");
            }
        }
        System.out.println();
        }
        System.out.println();
    }
}








       /* public static int[] inputnum(int[] value,int large,int size){
            int place=0;
            int x=0;
            int[] largest =new int[large];
                  //      System.out.println("size "+ size);

            for(int i=0;i<size;i++){
                if(value[i]==large){
//                    largest[x]=value[i];
                    largest[x]=i;
                    x=x+1;
                    place=i+1;
                    System.out.println("the largest is "+ value[i]+ " at "+i);
                    System.out.println("the largest is value "+ largest[x]);
                 //   large=value[i];
//                    place=i+1;
                }
//                            System.out.println("x "+ x);

            }
//                        System.out.println("large "+ large);

            System.out.println("passes input num with x at "+x);
            return largest;
    }*/
//    static ArrayList recSearch(int arr[], int bottom, int top, int value, ArrayList a1){//gets all occurences of value in arr and puts them in a1
/*for (int j=0; j < a1.length; j++)
        {
            //if(a1[j]!=-1){
//            System.out.print(a1[j]+" ");
            a[num][j]=a1[j];
        }
*/   //     System.out.println();
    /*
    make 2 lists with to have about the same number of elements
    one has random elements
    when the largest value of the random list is 18 
    have a search for when there is an 18 
    when there is an 18 make the value
    */
    
    
/*
            public static int readlist(int[] value, int size){
            int large=0;
            int place=0;
            System.out.println(value.length+" "+size);
            System.out.println("value.length+size");
            for(int i=0;i<=size;i++){
                            System.out.println("i "+ i);

            System.out.println(i+": "+value[i]);
/*                if(value[i]>large){
                    place=i+1;
                    System.out.println("the new largest is "+ value[i]+ " at "+place);
                    large=value[i];
//                    place=i+1;
                }
            }
            return large;
        }

    */    
       /* if(top<bottom){
            System.out.println("first if"+top+" "+bottom);
            return a1;
        }
        if(arr[bottom]==value){
            System.out.println("2nd if "+bottom);
            a1.add(bottom);
        }
        if(arr[top]==value){
            System.out.println("3rd if "+top);
            a1.add(top);
        }
        System.out.println(a1);
        recSearch(arr,bottom+1,top-1,value,a1);
        return a1;
    *//*    static int recSearch(int arr[], int min, int max, int value){
        if(max<min){
            return -1;
        }
        if(arr[min]==value){
            return min;
        }
        if(arr[max]==value){
            return max;
        }
        return recSearch(arr,min+1,max-1,value);
    }
*/  

//order the array numerically 
//use different search like jump

//check to see if I can remove a value from a certain place in the list so I can take out the largest number and that be it