/*
project name: Class7ds
program:search
Author: Erik Bailey
Date: Oct 29 2020
Synoposis: 
tells what indexes of the array a certain number can be found
*/
package pkgclass.pkg7.ds;
public class search {
    int[] recSearch(int arr[], int bottom, int top, int value, int[] a1,int x){//gets all occurences of value in arr and puts them in a1
        while(top>=bottom){
            if(arr[bottom]==value){
                a1[x]=bottom;
                x=x+1;
            }
            bottom=bottom+1;
        }
        while(x<a1.length){
            a1[x]=-1;
            x=x+1;
        }
        return a1;
    }
}