/*
project name: Class7ds
program:largest
Author: Erik Bailey
Date: Oct 29 2020
Synoposis: 
Finds the largest number
*/
package pkgclass.pkg7.ds;
public class largest {
    public int largestinlist(int[] value, int size){
        int large=0;
        int place=0;
        for(int i=0;i<size;i++){
            if(value[i]>large){
                place=i+1;
                large=value[i];
            }
        }
        return large;
    }
}
/*
        public int largestinlist(ArrayList value, int size){
            int large=0;
            int place=0;
            int a;
            for(int i=0;i<size;i++){
//            System.out.println(i+": "+value[i-1]);
                a=(int) value.get(i);
                if(a>large){
                    place=i+1;
                    System.out.println("the new largest is "+ a+ " at "+place);
                    large=a;
//                    place=i+1;
                }
            }
            return large;
        }

*/