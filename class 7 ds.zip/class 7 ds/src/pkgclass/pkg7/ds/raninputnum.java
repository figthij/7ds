/*
project name: Class7ds
program:raninputnum
Author: Erik Bailey
Date: Oct 29 2020
Synoposis: 
Makes random numbers 
*/
package pkgclass.pkg7.ds;
import java.util.Random;
public class raninputnum {
    public void raninputnum(int[] value,int i){
        Random rnum = new Random();
        value[i]=rnum.nextInt(1000);
    }
}
